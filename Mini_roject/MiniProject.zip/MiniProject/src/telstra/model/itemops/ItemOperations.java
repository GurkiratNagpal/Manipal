package telstra.model.itemops;

import teltsra.model.Item;

public interface ItemOperations {
	// add items
	// delete items
	// update items
	// inventory calculation
	// get item

	// assign item id
	// location

	String addItems(Item item, int category, String type);

	String deleteItems(int itemId);

	String updateItems(int itemId, int upPrice);

	// double getInventoryValue();

	// ArrayList<Item> getAllItems();

	int assignItemId();

	// String assignLocation();

}
