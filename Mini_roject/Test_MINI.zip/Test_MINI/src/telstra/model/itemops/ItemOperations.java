package telstra.model.itemops;

import teltsra.model.Item;

public interface ItemOperations {

	String addItems(Item item);

	int assignItemId();


}
