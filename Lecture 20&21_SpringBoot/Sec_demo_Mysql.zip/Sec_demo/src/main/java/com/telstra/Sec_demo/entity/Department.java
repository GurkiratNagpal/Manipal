package com.telstra.Sec_demo.entity;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

@Entity
public @Data class Department {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long did;
    @NotBlank(message = "Pls pass the dept name")
//    @Length(max = 5, min = 1)
//    @Size
//    @Positive
//    @Email
    private String dname;
    private String dadd;
    private String dcode;




}
