package com.telstra.Sec_demo.entity;


import java.util.List;


public interface DeptServ {


    Department saveDept(Department d);

    List<Department> giveall();

    Department giveOne(Long did) throws DepartmentNotFound;

    String delOne(Long did);

    Department updateWholeDept(Long did, Department d);

    Department fetchByDname(String dname);
}
