package com.telstra.Sec_demo.entity;

import com.telstra.Sec_demo.entity.Reposit.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class DeptServImp implements DeptServ{


    @Autowired
    private DepartmentRepository repo;

    @Override
    public Department saveDept(Department d) {
        return repo.save(d);
    }

    @Override
    public List<Department> giveall() {
        return repo.findAll();
    }

    @Override
    public Department giveOne(Long did) throws DepartmentNotFound {
        Optional<Department> d = repo.findById(did);
        if (d.isEmpty()){
            throw new DepartmentNotFound("Department not found");
        }
        return d.get();
    }

    @Override
    public String delOne(Long did) {
        repo.deleteById(did);
        return "Department deleted Successfully";
    }

    @Override
    public Department updateWholeDept(Long did, Department d) {
        Department deptdb = repo.findById(did).get();
        if (Objects.nonNull(d.getDname()) && !"".equalsIgnoreCase(d.getDname())){
            deptdb.setDname(d.getDname());
        }

        if (Objects.nonNull(d.getDadd()) && !"".equalsIgnoreCase(d.getDadd())){
            deptdb.setDadd(d.getDadd());
        }

        if (Objects.nonNull(d.getDcode()) && !"".equalsIgnoreCase(d.getDcode())){
            deptdb.setDcode(d.getDcode());
        }
        return repo.save(deptdb);
    }

    @Override
    public Department fetchByDname(String dname) {
        return repo.findByDnameIgnoreCase(dname);
    }
}
