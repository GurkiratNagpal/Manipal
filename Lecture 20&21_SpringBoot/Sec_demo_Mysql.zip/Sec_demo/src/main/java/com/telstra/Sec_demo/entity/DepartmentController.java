package com.telstra.Sec_demo.entity;


//
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.log4j2.Log4J2LoggingSystem;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
public class DepartmentController {

    @Autowired
    private DeptServ ds;
    private final Logger lg = LoggerFactory.getLogger(DepartmentController.class);


    @PostMapping("/department")
    public Department saveDept(@Valid @RequestBody Department d){
        lg.info("Inside Saving Dept!!");
        return ds.saveDept(d);
    }

    @GetMapping("/department")
    public List<Department>  fetchall(){

        return ds.giveall();

    }


    @GetMapping("/department/{id}")
    public Department fetchbyId(@PathVariable("id") Long did) throws DepartmentNotFound {

        return ds.giveOne(did);
    }

    @GetMapping("/department/name/{namedept}")
    public Department fetchbyName(@PathVariable("namedept") String dname){
        return ds.fetchByDname(dname);
    }



    @DeleteMapping("/department/{id}")
    public String delbyId(@PathVariable("id") Long did){
        return ds.delOne(did);
    }


    @PutMapping("/department/{id}")
    public Department updateWhole(@PathVariable("id") Long did, @RequestBody Department d) {
        return ds.updateWholeDept(did, d);
    }
}
