package com.telstra.Sec_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecDemoApplication.class, args);
	}

}
