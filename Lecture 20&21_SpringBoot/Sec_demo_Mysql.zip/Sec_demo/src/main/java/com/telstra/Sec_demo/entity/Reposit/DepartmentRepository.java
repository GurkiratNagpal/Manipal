package com.telstra.Sec_demo.entity.Reposit;


import com.telstra.Sec_demo.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {

        public Department findByDname(String n);

        public Department findByDnameIgnoreCase(String n);

}
