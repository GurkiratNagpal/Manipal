package com.telstra.Sec_demo.entity;

public class DepartmentNotFound extends Exception {


    public DepartmentNotFound() {
        super();
    }

    public DepartmentNotFound(Throwable cause) {
        super(cause);
    }

    public DepartmentNotFound(String message) {
        super(message);
    }

    protected DepartmentNotFound(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public DepartmentNotFound(String message, Throwable cause) {
        super(message, cause);
    }
}
